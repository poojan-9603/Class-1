# homework0

This is the template for our starter assignment in Secure Web Application Development.

TLDR: this assignment is mostly a demo of the autograding infrastructure. All you need to do for full credit is:

- put your email address in `student.json`
- update your email address in `main.ts` so that "website of (your email address)" shows up in the web page
- deploy your website to the web, using the service of your choice
  - Cloudflare Pages and Render are our official recommendations, but anything that is available on the Internet is fine.
- put the URL for your deployed website in `student.json`
- don't introduce any type errors, lint errors or warnings, or format errors
